<!doctype HTML>
<html>
<head>


</head>

<body> 
 <form name="contact_frm" action="index.php" method="post">
  <ul>
  <li><label>First name</label><input type="text" name="firstname" id="fname" /></li>
  <li><label>Last name</label><input type="text" name="lastname" id="fname" /></li>
  <li><label>Email address</label><input type="text" name="email" id="fname" /></li>
  <li><label>Enter username</label><input type="text" name="username" id="username" /></li>
  <li><label>Enter password</label><input type="password" name="password" id="password" /></li>
  <li><label>Retype password</label><input type="password" name="confirm_password" id="confirm_password" /></li>
  <li><label>Telephone no</label><input type="text" name="tel_no" id="tel_no" /></li>
  <li><input type="submit" value="send" /></li>
  </ul>
 
 
 
 
 </form>



</body>



</html>