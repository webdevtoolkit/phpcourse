<?php

foreach($errors as $row)
     {
	  echo $row . "</br>";
	  
	 
	 }
	 
?>